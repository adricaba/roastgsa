## ----load-packages, message=FALSE, warning=FALSE---------------------------
library( roastgsa )

## ---- message = FALSE------------------------------------------------------
library(GSEABenchmarkeR)
geo2keggR <- loadEData("geo2kegg", nr.datasets=4)
geo2kegg <- maPreproc(list(geo2keggR[[4]]))
y <- assays(geo2kegg[[1]])$expr
covar <- colData(geo2kegg[[1]])
covar$GROUP <- as.factor(covar$GROUP)
covar$BLOCK <- as.factor(covar$BLOCK)

## ---- message = FALSE------------------------------------------------------
library(EnrichmentBrowser)
kegg.gs <- getGenesets(org="hsa", db="kegg")
kegg.gs <- kegg.gs[which(sapply(kegg.gs,length)>10&sapply(kegg.gs,length)<500)]

## ---- message = FALSE------------------------------------------------------
library(preprocessCore)
ynorm <- normalize.quantiles(y)
rownames(ynorm) <- rownames(y)
colnames(ynorm) <- colnames(y)
par(mfrow=c(1,2))
boxplot(y, las = 2)
boxplot(ynorm, las = 2)
y <- ynorm

## ---- message = FALSE------------------------------------------------------
form = as.formula("~ BLOCK + GROUP")
design <- model.matrix(form, covar)
fit.maxmean.comp <- roastgsa(y, form = form, covar = covar,
                      contrast = "GROUP1", index = kegg.gs, nrot = 1000,
                      mccores = 1, set.statistic = "maxmean",
                      self.contained = FALSE, executation.info = FALSE)
f1 <- fit.maxmean.comp$res
rownames(f1) <- substr(rownames(f1),1,8)
head(f1)

fit.meanrank <- roastgsa(y, form = form, covar = covar,
                   contrast = 2, index = kegg.gs, nrot = 1000,
                   mccores = 1, set.statistic = "mean.rank",
                   self.contained = FALSE, executation.info = FALSE)
f2 <- fit.meanrank$res
rownames(f2) <- substr(rownames(f2),1,8)
head(f2)

## ---- message = FALSE------------------------------------------------------
plot(fit.maxmean.comp, type ="stats", whplot = 2,  gsainfo = TRUE,
    cex.sub = 0.8, lwd = 2)

## ---- message = FALSE------------------------------------------------------
plot(fit.meanrank,  type ="stats",  whplot = 1, gsainfo = TRUE,
     cex.sub = 0.8, lwd = 2)

## ---- message = FALSE------------------------------------------------------
plot(fit.maxmean.comp, type = "GSEA", whplot = 2, gsainfo =TRUE,
     maintitle = "", statistic = "mean")

plot(fit.meanrank, type = "GSEA",  whplot = 1, gsainfo =TRUE,
     maintitle = "", statistic = "mean")

## ---- message = FALSE------------------------------------------------------
hm <- heatmaprgsa_hm(fit.maxmean.comp, y, intvar = "GROUP", whplot = 3,
        toplot = TRUE, pathwaylevel = FALSE, mycol = c("orange","green",
        "white"), sample2zero = FALSE)

## ---- message = FALSE------------------------------------------------------
hm2 <- heatmaprgsa_hm(fit.maxmean.comp, y, intvar = "GROUP", whplot = 1:50,
        toplot = TRUE, pathwaylevel = TRUE, mycol = c("orange","green",
        "white"), sample2zero = FALSE)

## ---- message = FALSE------------------------------------------------------
ss1 <- ssGSA(y, obj=fit.maxmean.comp, method = c("GScor"))

## ---- message = FALSE------------------------------------------------------
plot(ss1, orderby = covar$GROUP, whplot = 1, col = as.numeric(covar$GROUP),
	  samplename = FALSE, pch =16, maintitle = "", ssgsaInfo = TRUE,
          cex.sub = 0.8, xlab = "Group", ylab = "zscore - GS")

## ---- message = FALSE------------------------------------------------------
# DO NOT RUN
# library(GEOquery)
# data <- getGEO('GSE145603')
# normdata <- (data[[1]])
# pd <- pData(normdata)
# pd$group_LGR5 <- pd[["lgr5:ch1"]]

## ---- message = FALSE------------------------------------------------------
# DO NOT RUN
# gspath = "path/to/folder/of/h.all.v7.2.symbols.gmt"
# gsetsel = "h.all.v7.2.symbols.gmt"

## ---- message = FALSE------------------------------------------------------
# DO NOT RUN
# form <- "~ -1 + group_LGR5"
# design <- model.matrix(as.formula(form),pd)
# cont.mat <- data.frame(Lgr5.high_Lgr5.neg = c(1,-1))
# rownames(cont.mat) <- colnames(design)

## ---- message = FALSE------------------------------------------------------
# DO NOT RUN
# mads <- apply(exprs(normdata), 1, mad)
# gu <- strsplit(fData(normdata)[["Gene Symbol"]], split=' \\/\\/\\/ ')
# names(gu) <- rownames(fData(normdata))
# gu <- gu[sapply(gu, length)==1]
# gu <- gu[gu!='' & !is.na(gu) & gu!='---']
# ps <- rep(names(gu), sapply(gu, length))
# gs <- unlist(gu)
# pss <- tapply(ps, gs, function(o) names(which.max(mads[o])))
# psgen.mvar <- pss

## ---- message = FALSE------------------------------------------------------
# DO NOT RUN
# roast1 <- roastgsa(exprs(normdata), form = form, covar = pd,
#                    psel = psgen.mvar, contrast = cont.mat[, 1],
#                    gspath = gspath, gsetsel = gsetsel, nrot = 1000,
#                    mccores = 7, set.statistic = "maxmean")
#
# print(roast1)
#

